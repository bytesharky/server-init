//SOME PAGES ON THIS SERVER THAT YOU DO NOT HAVE PERMISSION TO ACCESS
// var str = document.getElementsByTagName('div')[0].innerHTML.toString();
// var i = 0;
// document.getElementsByTagName('div')[0].innerHTML = "";

// setTimeout(function () {
//     var se = setInterval(function () {
//         i++;
//         document.getElementsByTagName('div')[0].innerHTML = str.slice(0, i) + "_";
//         if (i == str.length) {
//             clearInterval(se);
//             document.getElementsByTagName('div')[0].innerHTML = str;
//         }
//     }, 10);
// }, 0);

// ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑
// 上面是原始打字机效果，由于会把html标签拆解，
// 加上浏览器的自动修复标签功能，会使页面产生抖动

// Sharky 2024年11月4日 23:38:19
window.onload = function() {
    // 获取打字效果的根元素
    const div = document.getElementById('content');

    // 用于存储每个文本节点的引用和内容
    const textNodes = [];

    // 递归遍历并记录文本节点的引用和内容，然后清空节点
    function recordAndClearTextNodes(node) {
        node.childNodes.forEach(child => {
            if (child.nodeType === Node.TEXT_NODE) {
                // 去除多余的空格和换行
                const trimmedContent = child.textContent.replace(/^\s+$/g, '').replace(/\s+/g, ' ');
                if (trimmedContent) {
                    textNodes.push({ node: child, content: trimmedContent });
                    child.textContent = "";
                }
            } else {
                    // 递归处理子节点
                recordAndClearTextNodes(child); 
            }
        });
    }

    // 动画函数，模拟打字机效果
    function animateText(index) {
        if (index < textNodes.length) {
            const { node, content } = textNodes[index];
            let outstr = "";
            let i = 0;

            const interval = setInterval(() => {
                if (i < content.length) {
                    // 逐字添加文本内容，并带一个光标
                    outstr += content[i++];
                    node.textContent = outstr + "_"; 
                } else {
                    // 节点动画完成后处理下一个文本节点
                    node.textContent = outstr;
                    clearInterval(interval);
                    animateText(index + 1); 
                }
            }, 20); // <<== 这里可调整速度
        }
    }

    // 清空所有文本节点并记录内容
    recordAndClearTextNodes(div);
    // 启动动画
    animateText(0);
}